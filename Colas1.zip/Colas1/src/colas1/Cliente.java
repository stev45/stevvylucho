
package colas1;


public class Cliente {
    
    private String Nombre;
    private int cc;
    private String Tipodecliente;
    public Cliente(){
        
    }

    public Cliente(String Nombre, int cc, String Tipodecliente) {
        this.Nombre = Nombre;
        this.cc = cc;
        this.Tipodecliente = Tipodecliente;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }

    public String getTipodecliente() {
        return Tipodecliente;
    }

    public void setTipodecliente(String Tipodecliente) {
        this.Tipodecliente = Tipodecliente;
    }
}
